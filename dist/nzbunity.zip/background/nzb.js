var NZBPriority;
(function (NZBPriority) {
    NZBPriority[NZBPriority["default"] = -100] = "default";
    NZBPriority[NZBPriority["paused"] = -2] = "paused";
    NZBPriority[NZBPriority["low"] = -1] = "low";
    NZBPriority[NZBPriority["normal"] = 0] = "normal";
    NZBPriority[NZBPriority["high"] = 1] = "high";
    NZBPriority[NZBPriority["force"] = 2] = "force";
})(NZBPriority || (NZBPriority = {}));
var NZBPostProcessing;
(function (NZBPostProcessing) {
    NZBPostProcessing[NZBPostProcessing["default"] = -1] = "default";
    NZBPostProcessing[NZBPostProcessing["none"] = 0] = "none";
    NZBPostProcessing[NZBPostProcessing["repair"] = 1] = "repair";
    NZBPostProcessing[NZBPostProcessing["repair_unpack"] = 2] = "repair_unpack";
    NZBPostProcessing[NZBPostProcessing["repair_unpack_delete"] = 3] = "repair_unpack_delete";
})(NZBPostProcessing || (NZBPostProcessing = {}));
class NZBHost {
    // infinityString:string = '&#8734;';
    constructor(options = {}) {
        this.infinityString = '∞';
        this.displayName = options.displayName || this.name;
        this.host = options.host || 'localhost';
        this.hostParsed = Util.parseUrl(this.host);
    }
}
class SABnzbdHost extends NZBHost {
    constructor(options = {}) {
        super(options);
        this.name = 'SABnzbd';
        this.apikey = options.apikey || '';
        let pathname = `${this.hostParsed.pathname}/sabnzbd/api`.replace(/\/+/g, '/');
        this.apiUrl = `${this.hostParsed.protocol}//${this.hostParsed.hostname}:${this.hostParsed.port}${pathname}`;
    }
    call(operation, params = {}) {
        let request = {
            method: 'GET',
            url: this.apiUrl,
            params: {
                apikey: this.apikey,
                output: 'json',
                mode: operation
            }
        };
        for (let k in params) {
            request.params[k] = String(params[k]);
        }
        return Util.request(request)
            .then((r) => {
            // check for error condition
            if (r.status === false && r.error) {
                return { success: false, operation: operation, error: r.error };
            }
            // Collapse single key result
            if (Object.keys(r).length === 1) {
                r = r[Object.keys(r)[0]];
            }
            return { success: true, operation: operation, result: r };
        })
            .catch((err) => {
            return { success: false, operation: operation, error: err };
        });
    }
    getQueue() {
        let queue;
        return this.call('queue')
            .then((r) => {
            if (!r.success)
                return null;
            let speedBytes = null;
            let speedMatch = r.result['speed'].match(/(\d+)\s+(\w+)/i);
            if (speedMatch) {
                speedBytes = parseInt(speedMatch[1]);
                switch (speedMatch[2].toUpperCase()) {
                    case 'G':
                        speedBytes *= Util.Gigabyte;
                        break;
                    case 'M':
                        speedBytes *= Util.Megabyte;
                        break;
                    case 'K':
                        speedBytes *= Util.Kilobyte;
                        break;
                }
            }
            let maxSpeedBytes = parseInt(r.result['speedlimit_abs']);
            queue = {
                status: Util.ucFirst(r.result['status']),
                speed: Util.humanSize(speedBytes) + '/s',
                speedBytes: speedBytes,
                maxSpeed: maxSpeedBytes ? Util.humanSize(maxSpeedBytes) : '',
                maxSpeedBytes: maxSpeedBytes,
                sizeRemaining: r.result['sizeleft'],
                timeRemaining: speedBytes > 0 ? r.result['timeleft'] : this.infinityString,
                categories: null,
                queue: []
            };
            r.result['slots'].forEach((s) => {
                let size = Math.floor(parseFloat(s['mb']) * Util.Megabyte); // MB convert to Bytes
                let sizeRemaining = Math.floor(parseFloat(s['mbleft']) * Util.Megabyte); // MB convert to Bytes
                let item = {
                    id: s['nzo_id'],
                    status: Util.ucFirst(s['status']),
                    name: s['filename'],
                    category: s['cat'],
                    size: Util.humanSize(size),
                    sizeBytes: size,
                    sizeRemaining: Util.humanSize(sizeRemaining),
                    sizeRemainingBytes: sizeRemaining,
                    timeRemaining: speedBytes > 0 ? s['timeleft'] : this.infinityString,
                    percentage: Math.floor(((size - sizeRemaining) / size) * 100)
                };
                queue.queue.push(item);
            });
            return this.getCategories()
                .then((categories) => {
                queue.categories = categories;
                return queue;
            });
        });
    }
    getCategories() {
        return this.call('get_cats')
            .then((r) => {
            let categories;
            if (r.success) {
                categories = r.result.filter((i) => {
                    return i !== '*';
                });
            }
            return categories;
        });
    }
    addUrl(url, options = {}) {
        let params = { name: url };
        for (let k in options) {
            let val = String(options[k]);
            if (k === 'name') {
                params.nzbname = val;
            }
            else if (k === 'category') {
                params.cat = val;
            }
            else {
                params[k] = val;
            }
        }
        return this.call('addurl', params)
            .then((r) => {
            if (r.success) {
                let ids = r.result['nzo_ids'];
                r.result = ids.length ? ids[0] : null;
            }
            return r;
        });
    }
    setMaxSpeed(bytes) {
        let speed = bytes ? `${bytes / Util.Kilobyte}K` : '100';
        return this.call('config', { name: 'speedlimit', value: speed })
            .then((r) => {
            if (r.success) {
                r.result = true;
            }
            return r;
        });
    }
    resumeQueue() {
        return this.call('resume')
            .then((r) => {
            if (r.success) {
                r.result = true;
            }
            return r;
        });
    }
    pauseQueue() {
        return this.call('pause')
            .then((r) => {
            if (r.success) {
                r.result = true;
            }
            return r;
        });
    }
    test() {
        return this.call('fullstatus', { skip_dashboard: 1 })
            .then((r) => {
            if (r.success) {
                r.result = true;
            }
            return r;
        });
    }
}
class NZBGetHost extends NZBHost {
    constructor(options = {}) {
        super(options);
        this.name = 'NZBGet';
        this.username = options.username || '';
        this.password = options.password || '';
        let pathname = `${this.hostParsed.pathname}/jsonrpc`.replace(/\/+/g, '/');
        this.apiUrl = `${this.hostParsed.protocol}//${this.hostParsed.hostname}:${this.hostParsed.port}${pathname}`;
    }
    call(operation, params = []) {
        let request = {
            method: 'POST',
            url: this.apiUrl,
            username: this.username,
            password: this.password,
            json: true,
            params: {
                method: operation,
                params: params
            }
        };
        for (let k in params) {
            request.params[k] = String(params[k]);
        }
        return Util.request(request)
            .then((r) => {
            // check for error condition
            if (r.error) {
                return { success: false, operation: operation, error: `${r.error.name}: ${r.error.message}` };
            }
            return { success: true, operation: operation, result: r.result };
        })
            .catch((err) => {
            return { success: false, operation: operation, error: err };
        });
    }
    getQueue() {
        let queue;
        return this.call('status')
            .then((r) => {
            if (!r.success)
                return null;
            let status = r.result['ServerStandBy']
                ? 'idle'
                : r.result['DownloadPaused']
                    ? 'paused'
                    : 'downloading';
            let speedBytes = r.result['DownloadRate']; // in Bytes / Second
            let maxSpeedBytes = parseInt(r.result['DownloadLimit']);
            let sizeRemaining = Math.floor(r.result['RemainingSizeMB'] * Util.Megabyte); // MB convert to Bytes
            let timeRemaining = Math.floor(sizeRemaining / speedBytes); // Seconds
            queue = {
                status: Util.ucFirst(status),
                speed: Util.humanSize(speedBytes) + '/s',
                speedBytes: speedBytes,
                maxSpeed: maxSpeedBytes ? Util.humanSize(maxSpeedBytes) : '',
                maxSpeedBytes: maxSpeedBytes,
                sizeRemaining: Util.humanSize(sizeRemaining),
                timeRemaining: speedBytes > 0 ? Util.humanSeconds(timeRemaining) : this.infinityString,
                categories: null,
                queue: []
            };
            return this.call('listgroups');
        })
            .then((r) => {
            if (!(r && r.success))
                return null;
            r.result.forEach((s) => {
                let size = Math.floor(s['FileSizeMB'] * Util.Megabyte); // MB convert to Bytes
                let sizeRemaining = Math.floor(s['RemainingSizeMB'] * Util.Megabyte); // MB convert to Bytes
                let timeRemaining = Math.floor(sizeRemaining / queue.speedBytes); // Seconds
                let item = {
                    id: s['NZBID'],
                    status: Util.ucFirst(s['Status']),
                    name: s['NZBNicename'],
                    category: s['Category'],
                    size: Util.humanSize(size),
                    sizeBytes: size,
                    sizeRemaining: Util.humanSize(sizeRemaining),
                    sizeRemainingBytes: sizeRemaining,
                    timeRemaining: queue.speedBytes > 0 ? Util.humanSeconds(timeRemaining) : this.infinityString,
                    percentage: Math.floor(((size - sizeRemaining) / size) * 100)
                };
                queue.queue.push(item);
            });
            return this.getCategories()
                .then((categories) => {
                queue.categories = categories;
                return queue;
            });
        });
    }
    getCategories() {
        // Ok, this is weird. NZBGet API does not have a method to get categories, but the categories
        // are listed in the config, so let's get them there.
        return this.call('config')
            .then((r) => {
            let config = r.result;
            let categories;
            if (r.success) {
                categories = config.filter((i) => {
                    return /Category\d+\.Name/i.test(i.Name);
                })
                    .map((i) => {
                    return i.Value;
                });
            }
            return categories;
        });
    }
    addUrl(url, options = {}) {
        let params = [
            '',
            url,
            options.category || '',
            options.priority || NZBPriority.normal,
            false,
            false,
            '',
            0,
            'SCORE',
            [] // PPParameters
        ];
        return this.call('append', params)
            .then((r) => {
            if (r.success) {
                r.result = String(r.result);
            }
            return r;
        });
    }
    setMaxSpeed(bytes) {
        let speed = bytes ? bytes / Util.Kilobyte : 0;
        return this.call('rate', [speed])
            .then((r) => {
            if (r.success) {
                r.result = true;
            }
            return r;
        });
    }
    resumeQueue() {
        return this.call('resumedownload')
            .then((r) => {
            if (r.success) {
                r.result = true;
            }
            return r;
        });
    }
    pauseQueue() {
        return this.call('pausedownload')
            .then((r) => {
            if (r.success) {
                r.result = true;
            }
            return r;
        });
    }
    test() {
        return this.call('status')
            .then((r) => {
            if (r.success) {
                r.result = true;
            }
            return r;
        });
    }
}
