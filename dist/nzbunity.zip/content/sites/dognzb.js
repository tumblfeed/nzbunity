class NZBUnityDognzb {
    constructor() {
        Util.storage.get('Providers')
            .then((opts) => {
            let provider = opts.Providers && opts.Providers.dognzb;
            let enabled = provider ? provider.Enabled : true;
            if (enabled) {
                console.info(`[NZB Unity] Initializing 1-click functionality...`);
                this.username = this.getUsername();
                this.initializeLinks();
            }
            else {
                console.info(`[NZB Unity] 1-click functionality disabled for this site`);
            }
        });
    }
    getUsername() {
        return $('#label').text().trim();
    }
    getNzbUrl(id) {
        let rsstoken = $('input[name="rsstoken"]').val();
        return `${window.location.protocol}//${window.location.host}/fetch/${id}/${rsstoken}`;
    }
    initializeLinks() {
        // Any page with a table of downloads (browse, search)
        if ($('tr[id^="row"]').length) {
            $('[onclick^="doOneDownload"]').each((i, el) => {
                let a = $(el);
                let idMatch = a.attr('onclick').match(/\('(\w+)'\)/i);
                let id = idMatch && idMatch[1];
                // Get the category
                let catLabel = a.closest('tr')
                    .find('.label').not('.label-empty').not('.label-important');
                let category = catLabel.text();
                let catSrc = 'default';
                a.closest('td').attr('width', '36');
                a.css({ float: 'left' });
                let link = PageUtil.createAddUrlLink({
                    url: this.getNzbUrl(id),
                    category: category
                }, el)
                    .on('addUrl.success', (e) => {
                    catLabel.closest('tr')
                        .prepend('<td width="19"><div class="dog-icon-tick"></div></td>');
                });
            });
        }
        else if (window.location.pathname.startsWith('/details')) {
            let id = window.location.pathname.match(/\/details\/(\w+)/i)[1];
            // Get the category
            let category = '';
            let catSrc = 'default';
            let catLabel = $('#details tr:nth-child(3) td:nth-child(2)');
            if (catLabel.length) {
                category = catLabel.text().split(/\s*->\s*/)[0];
            }
            // a.closest('td').attr('width', '36');
            // a.css({ float: 'left' })
            let link = PageUtil.createAddUrlLink({
                url: this.getNzbUrl(id),
                category: category
            })
                .appendTo($('#preview .btn-group').closest('tr').find('td:first-child'));
        }
    }
}
let dognzb = new NZBUnityDognzb();
